
public class Main {

    public static void main(String[] args) {

        EncryptionProgram ep=new EncryptionProgram();



    }f

}
